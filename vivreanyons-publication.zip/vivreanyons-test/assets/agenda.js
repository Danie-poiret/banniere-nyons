const AGENDA_DATA='https://raw.githubusercontent.com/Danie-poiret/agenda-nyons/main/agenda.json';
function slugify(s){return (s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/['’]/g,'-').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').replace(/-+/g,'-')}
function fmtDate(s){if(!s)return'';const [y,m,d]=s.split('-').map(Number);return new Intl.DateTimeFormat('fr-FR',{day:'numeric',month:'long'}).format(new Date(y,m-1,d))}
async function loadAgenda(){const root=document.querySelector('[data-agenda]');if(!root)return;try{const r=await fetch(AGENDA_DATA,{cache:'no-store'});if(!r.ok)throw new Error('agenda');const data=await r.json();const today=new Date().toISOString().slice(0,10);const events=(data.events||[]).filter(e=>(e.end_date||e.start_date||'')>=today).sort((a,b)=>(a.start_date||'').localeCompare(b.start_date||'')).slice(0,6);if(!events.length){root.innerHTML='<p>Aucun événement à venir pour le moment.</p>';return}root.innerHTML=events.map(e=>{const slug=slugify(e.title);const u=`https://agenda.vivreanyons.fr/evenements/${slug}-${e.start_date}/`;return `<article class="event"><div class="event-date">${fmtDate(e.start_date)}${e.end_date&&e.end_date!==e.start_date?' → '+fmtDate(e.end_date):''}</div><h3>${e.title}</h3><p>${e.summary||'Retrouvez les informations pratiques sur la fiche événement.'}</p><a href="${u}">Voir la fiche agenda →</a></article>`}).join('')}catch(e){root.innerHTML='<p>Les prochains événements sont disponibles sur <a href="https://agenda.vivreanyons.fr/">agenda.vivreanyons.fr</a>.</p>'}}
function simplifyPontRomanPhotos(){
  if(!location.pathname.includes('/Pont-Roman-de-Nyons'))return;
  const figures=[...document.querySelectorAll('main figure')];
  figures.slice(2).forEach(f=>f.remove());
  document.querySelectorAll('main .photo-stack').forEach(stack=>{if(!stack.querySelector('figure'))stack.remove()});
  [...document.querySelectorAll('main p')].forEach(p=>{if(p.textContent.includes('Image improbable : une autruche'))p.remove()});
}
document.addEventListener('DOMContentLoaded',()=>{simplifyPontRomanPhotos();loadAgenda()});